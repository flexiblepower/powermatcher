package net.powermatcher.core.messaging.adapter.template.constants;

/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

/**
/**
 * This interface defines all constants used by the <code>ExampleAdapter</code> adapter.
 * 
 * @author IBM
 * @version 0.9.0
 */
public interface ExampleAdapterConstants {
	/**
	 * Define the example topic (String) constant.
	 */
	public static final String EXAMPLE_TOPIC_PREFIX = "Example";

}
