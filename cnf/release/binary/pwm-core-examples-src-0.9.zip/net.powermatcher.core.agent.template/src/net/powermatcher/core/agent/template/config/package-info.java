/**
 * <p>
 * The interfaces in the <code>net.powermatcher.core.agent.template.config</code> package
 * define the keys and default values for the configuration properties that are supported
 * by the PowerMatcher Agents implemented in this project.
 * </p>
 *
 * @since 0.7
 */
package net.powermatcher.core.agent.template.config;