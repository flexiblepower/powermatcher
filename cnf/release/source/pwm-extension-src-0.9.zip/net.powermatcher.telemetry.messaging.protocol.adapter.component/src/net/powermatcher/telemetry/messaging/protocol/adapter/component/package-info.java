/**
 * Package containing the telemetry adapter component for the OSGi platform.
 *
 * @since 0.7
 */
package net.powermatcher.telemetry.messaging.protocol.adapter.component;