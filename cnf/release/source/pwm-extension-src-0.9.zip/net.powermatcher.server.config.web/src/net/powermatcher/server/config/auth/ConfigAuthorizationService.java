package net.powermatcher.server.config.auth;

/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

public interface ConfigAuthorizationService {
	
	public boolean isAuthorized(String userid, String nodeid);

}
