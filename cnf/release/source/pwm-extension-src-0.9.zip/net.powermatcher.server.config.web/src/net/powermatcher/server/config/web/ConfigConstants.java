package net.powermatcher.server.config.web;

/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

public interface ConfigConstants {
	
	/**
	 * Configuration service parameter node id.
	 */
	public static final String CONFIG_PARAMETER_NODE_ID = "nodeid";
	
	/**
	 * Topic name suffix of the configuration update trigger.
	 */
	public static final String CONFIG_UPDATE_TOPIC_SUFFIX = "Update";
	
	/**
	 * MIME type of the Configuration Manager service (servlet) response.
	 */
	public static final String CONFIG_SERVICE_MIME_TYPE = "application/xml"; // ("text/xml"  is deprecated)

}
