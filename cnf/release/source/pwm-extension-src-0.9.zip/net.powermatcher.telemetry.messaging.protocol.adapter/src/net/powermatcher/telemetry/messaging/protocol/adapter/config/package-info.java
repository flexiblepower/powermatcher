/**
 * Package containing configuration classes for telemetry adapters.
 *
 * @since 0.7
 */
package net.powermatcher.telemetry.messaging.protocol.adapter.config;