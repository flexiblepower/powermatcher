/**
 * Implements an adapter for publishing and receiving telemetry data messages.
 *
 * @since 0.7
 */
package net.powermatcher.telemetry.messaging.protocol.adapter;