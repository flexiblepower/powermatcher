/**
 * Package containing interfaces for telemetry adapter constants.
 *
 * @since 0.7
 */
package net.powermatcher.telemetry.messaging.protocol.adapter.constants;