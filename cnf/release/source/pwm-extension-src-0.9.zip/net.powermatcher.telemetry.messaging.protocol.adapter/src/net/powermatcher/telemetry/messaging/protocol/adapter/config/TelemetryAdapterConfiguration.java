package net.powermatcher.telemetry.messaging.protocol.adapter.config;

import net.powermatcher.core.messaging.framework.config.MessagingAdapterConfiguration;

/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

/**
 * Defines the interface of telemetry adapter configuration, configuration properties
 * and constants.
 * 
 * <p>
 * A TelemetryAdapterConfiguration object configures a TelemetryAdapter instance. 
 * </p>
 * @author IBM
 * @version 0.9.0
 * 
 * @see MessagingAdapterConfiguration
 */
public interface TelemetryAdapterConfiguration extends MessagingAdapterConfiguration {

}
