/**
 * Package containing telemetry service definitions.
 *
 * @since 0.7
 */
package net.powermatcher.telemetry.service;