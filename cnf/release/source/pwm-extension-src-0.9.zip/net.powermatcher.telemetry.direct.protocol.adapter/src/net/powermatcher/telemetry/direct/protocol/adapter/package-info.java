/**
 * Package containing the telemetry adapter for a direct connection.
 *
 * @since 0.7
 */
package net.powermatcher.telemetry.direct.protocol.adapter;