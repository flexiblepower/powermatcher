package net.powermatcher.core.agent.concentrator.service;

/********************************************
 * Copyright (c) 2012 Alliander.           *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

/**
 * @author IBM
 * @version 0.9.0
 */
public interface PeakShavingNotificationService {
	/**
	 * The peak shaving allocation has been updated, as a result of updated
	 * bids and/or a price update.
	 */
	public void updatedAllocation();

}
