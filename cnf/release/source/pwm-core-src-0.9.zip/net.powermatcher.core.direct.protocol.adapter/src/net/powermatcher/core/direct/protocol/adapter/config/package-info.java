/**
 * Package containing the configurations for the protocol, logging and matcher adapters for a direct connection.
 *
 * @since 0.7
 */
package net.powermatcher.core.direct.protocol.adapter.config;