/**
 * Package containing the market basis adapter configuration.
 *
 * @since 0.7
 */
package net.powermatcher.core.agent.marketbasis.adapter.config;