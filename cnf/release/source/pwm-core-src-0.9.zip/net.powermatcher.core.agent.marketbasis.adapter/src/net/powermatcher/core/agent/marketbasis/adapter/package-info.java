/**
 * Package containing the market basis adapter implementation.
 *
 * @since 0.7
 */
package net.powermatcher.core.agent.marketbasis.adapter;