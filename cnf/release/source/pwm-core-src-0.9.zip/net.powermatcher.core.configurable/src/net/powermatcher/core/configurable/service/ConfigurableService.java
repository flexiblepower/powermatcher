package net.powermatcher.core.configurable.service;


/********************************************
 * Copyright (c) 2011 Alliander.            *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

/**
 * @author IBM
 * @version 0.9.0
 * 
 * <p>
 * Defines the interface for objects for which a configuration
 * can be set.
 * </p>
 */
public interface ConfigurableService {
	/**
	 * Gets the configuration (ConfigurationService) value.
	 * 
	 * @return The configuration (<code>ConfigurationService</code>) value.
	 * @see #setConfiguration(ConfigurationService)
	 */
	public ConfigurationService getConfiguration();

	/**
	 * Sets the configuration value.
	 * 
	 * @param configuration
	 *            The configuration (<code>ConfigurationService</code>)
	 *            parameter.
	 * @see #getConfiguration()
	 */
	public void setConfiguration(final ConfigurationService configuration);

}
