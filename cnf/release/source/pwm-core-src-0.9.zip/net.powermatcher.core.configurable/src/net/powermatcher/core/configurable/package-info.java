/**
 * Providing the implementation of the ConfigurableService.
 *
 * @since 0.7
 */
package net.powermatcher.core.configurable;