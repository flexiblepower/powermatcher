/**
 * Contains the interface definitions for configurable objects.
 *
 * @since 0.7
 */
package net.powermatcher.core.configurable.service;