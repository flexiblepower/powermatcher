/**
 * Package containing the market basis adapter component for the OSGi platform.
 *
 * @since 0.7
 */
package net.powermatcher.core.agent.marketbasis.adapter.component;