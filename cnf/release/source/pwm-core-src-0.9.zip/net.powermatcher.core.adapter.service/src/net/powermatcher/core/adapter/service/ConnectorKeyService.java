package net.powermatcher.core.adapter.service;

/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

/**
 * Key type for identifying connectors in collections. 
 * @author IBM
 * @version 0.9.0
 */

public interface ConnectorKeyService {

}
