/**
 * Package for the service definition of an adapter and connector.
 *
 * @since 0.7
 */
package net.powermatcher.core.adapter.service;