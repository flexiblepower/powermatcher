/**
 * Package for the abstract adapter factory component.
 *
 * @since 0.7
 */
package net.powermatcher.core.adapter.component;