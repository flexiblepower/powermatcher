package net.powermatcher.core.messaging.service;


/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

/**
 * @author IBM
 * @version 0.9.0
 */
public interface MessagingConnectionDefinition {

	/**
	 * Create a new connection from the connection definition
	 * 
	 * @return Newly created connection, ready for adapter binding.
	 */
	public MessagingConnectionService createConnection();

}
