/**
 * Package for PowerMatcher framework core messaging configuration.
 *
 * @since 0.7
 */
package net.powermatcher.core.messaging.framework.config;