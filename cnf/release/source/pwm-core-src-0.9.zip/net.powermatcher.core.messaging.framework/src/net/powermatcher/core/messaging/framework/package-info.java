/**
 * Package for PowerMatcher framework core message classes MessagingAdapter and Topic.
 *
 * @since 0.7
 */
package net.powermatcher.core.messaging.framework;