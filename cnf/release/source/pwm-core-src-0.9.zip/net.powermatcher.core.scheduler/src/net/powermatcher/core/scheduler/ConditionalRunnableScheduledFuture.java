package net.powermatcher.core.scheduler;

/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

import java.util.concurrent.RunnableScheduledFuture;

/**
 * @author IBM
 * @version 0.9.0
 */
public interface ConditionalRunnableScheduledFuture<V> extends RunnableScheduledFuture<V> {

	/**
	 * @return
	 */
	public int getCoreIndex();

	/**
	 * @return
	 */
	public int getCycle();

	/**
	 * @return
	 */
	public long getTime();

	/**
	 * @return
	 */
	public boolean isReadyToRun();

	/**
	 * @param readyToRun
	 */
	public void setReadyToRun(boolean readyToRun);

}
