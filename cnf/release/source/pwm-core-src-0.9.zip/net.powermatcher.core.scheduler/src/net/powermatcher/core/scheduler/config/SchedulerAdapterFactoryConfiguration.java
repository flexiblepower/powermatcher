package net.powermatcher.core.scheduler.config;

/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

import net.powermatcher.core.object.config.IdentifiableObjectConfiguration;

/**
 * @author IBM
 * @version 0.9.0
 */
public interface SchedulerAdapterFactoryConfiguration extends IdentifiableObjectConfiguration {

	//TODO Add factory configuration parameters.
	
}
