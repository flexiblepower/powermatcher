/**
 * Package containing the interfaces for PowerMatcher Core.
 *
 * @since 0.7
 */
package net.powermatcher.core.agent.framework.service;