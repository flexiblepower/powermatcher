/**
 * Package containing the configuration classes for the key components of the framework, Agent and MatcherAgent.
 *
 * @since 0.7
 */
package net.powermatcher.core.agent.framework.config;