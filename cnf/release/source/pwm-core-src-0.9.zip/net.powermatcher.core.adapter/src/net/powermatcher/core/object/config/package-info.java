/**
 * Providing the configuration for the base classes.
 *
 * @since 0.7
 */
package net.powermatcher.core.object.config;