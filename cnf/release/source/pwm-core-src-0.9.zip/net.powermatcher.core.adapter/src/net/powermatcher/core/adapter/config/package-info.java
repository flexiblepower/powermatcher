/**
 * Package for the configuration for the adapter.
 *
 * @since 0.7
 */
package net.powermatcher.core.adapter.config;