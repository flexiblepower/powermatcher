/**
 * Package for the abstract adapter class and the connector tracker classes for component binding.
 *
 * @since 0.7
 */
package net.powermatcher.core.adapter;