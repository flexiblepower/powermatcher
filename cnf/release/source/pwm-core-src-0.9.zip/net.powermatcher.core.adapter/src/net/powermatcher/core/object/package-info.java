/**
 * Providing the abstract classes that for the basis of all PowerMatcher objects.
 *
 * @since 0.7
 */
package net.powermatcher.core.object;