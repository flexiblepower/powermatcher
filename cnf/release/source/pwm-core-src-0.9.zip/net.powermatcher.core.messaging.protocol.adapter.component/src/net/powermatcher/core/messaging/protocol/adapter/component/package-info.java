/**
 * Package containing the protocol, logging and matcher adapter components for the OSGi platform.
 *
 * @since 0.7
 */
package net.powermatcher.core.messaging.protocol.adapter.component;