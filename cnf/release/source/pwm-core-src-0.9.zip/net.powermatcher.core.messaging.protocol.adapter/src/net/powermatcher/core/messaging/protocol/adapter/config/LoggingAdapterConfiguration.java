package net.powermatcher.core.messaging.protocol.adapter.config;

import net.powermatcher.core.messaging.protocol.adapter.LoggingAdapter;


/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

/**
 * Defines the configuration properties, default values and constants for a LoggingProtocolAdapter object.
 * 
 * @author IBM
 * @version 0.9.0
 * 
 * @see LoggingAdapter
 */
public interface LoggingAdapterConfiguration extends BaseAdapterConfiguration {

}
