package net.powermatcher.core.messaging.protocol.adapter.constants;

/********************************************
 * Copyright (c) 2012, 2013 Alliander.      *
 * All rights reserved.                     *
 *                                          *
 * Contributors:                            *
 *     IBM - initial API and implementation *
 *******************************************/

/**
 * Defines the constants for the ProtocolAdapter.
 * 
 * @author IBM
 * @version 0.9.0
 */
public interface ProtocolAdapterConstants {

	/**
	 * Define the PowerMatcher topic prefix (String) constant.
	 */
	public static final String POWERMATCHER_TOPIC_PREFIX = "PowerMatcher";

}
