/**
 * Package containing the protocol, logging and matcher adapters.
 *
 * @since 0.7
 */
package net.powermatcher.core.messaging.protocol.adapter;