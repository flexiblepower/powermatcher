/**
 * Package for PowerMatcher adapter constants.
 *
 * @since 0.7
 */
package net.powermatcher.core.messaging.protocol.adapter.constants;