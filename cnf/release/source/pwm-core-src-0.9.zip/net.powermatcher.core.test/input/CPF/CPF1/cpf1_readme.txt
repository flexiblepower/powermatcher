For the CPF1 test the same input is used as for IAF1 test1. Except that
the equilibrium price in the input has been set to 38.0 (in stead off 37.753).