Note: the .emx UML2 models and diagrams were created with IBM Rational Software Architect 8.0.4.
